package annisamd.calculator_task;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText inputText;
    //Button button0, button1, button2, button3, button4, button5, button6, button7, button8, button9, buttonkali, buttonCC, buttonX2, buttontambah, buttonminus, buttonpersen, buttonResult, buttonroot, buttontutup, buttonbuka, buttonhapus, buttonbagi;
    private Button buttonX2;
    private Button buttonCC;
    private static final String TAG = "MainActivity";
    public String str ="";
    Character op = 'q';
    float i,numbr,numbrtmp;
    EditText showResult;
    //private ViewGroup rootView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showResult = (EditText)findViewById(R.id.editText);

    }

    public void btn1Clicked(View v){
        insert(1);

    }

    public void btn2Clicked(View v){
        insert(2);

    }
    public void btn3Clicked(View v){
        insert(3);

    }
    public void btn4Clicked(View v){
        insert(4);

    }
    public void btn5Clicked(View v){
        insert(5);

    }
    public void btn6Clicked(View v){
        insert(6);
    }
    public void btn7Clicked(View v){
        insert(7);

    }
    public void btn8Clicked(View v){
        insert(8);

    }
    public void btn9Clicked(View v){
        insert(9);

    }
    public void btnplusClicked(View v){
        perform();
        op = '+';

    }

    public void btnminusClicked(View v){
        perform();
        op = '-';

    }
    public void btndivideClicked(View v){
        perform();
        op = '/';

    }
    public void btnmultiClicked(View v){
        perform();
        op = '*';

    }
    public void btnequalClicked(View v){
        calculate();

    }

    public void btnclearClicked(View v){
        reset();
    }
    private void reset() {
        str ="";
        op ='q';
        numbr = 0;
        numbrtmp = 0;
        showResult.setText("");
    }
    private void insert(int j) {
        str = str+Integer.toString(j);
        numbr = Integer.valueOf(str).intValue();
        showResult.setText(str);

    }
    private void perform() {
        str = "";
        calculateNoShow();
        numbrtmp = numbr;

    }
    private void calculate() {
        if(op == '+')
            numbr = numbrtmp+numbr;
        else if(op == '-')
            numbr = numbrtmp-numbr;
        else if(op == '/')
            numbr = numbrtmp/numbr;
        else if(op == '*')
            numbr = numbrtmp*numbr;
        showResult.setText(""+numbr);
    }

    private void calculateNoShow() {
        if(op == '+')
            numbr = numbrtmp+numbr;
        else if(op == '-')
            numbr = numbrtmp-numbr;
        else if(op == '/')
            numbr = numbrtmp/numbr;
        else if(op == '*')
            numbr = numbrtmp*numbr;
    }

    /*
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonX2 = (Button) findViewById(R.id.buttonX2);
        buttonX2.setText(Html.fromHtml("x<supp>2</supp>"));
        inputText = (EditText) findViewById(R.id.editText);
        inputText.setText("0");
        buttonX2.setOnClickListener(this);
        ViewGroup rootView = (ViewGroup) findViewById(R.id.rootView);
        setupAllListeners(rootView);
    }
    */

    private void setupAllListeners (ViewGroup rootView){
        int numChild = rootView.getChildCount();
        //Log.v(TAG, "child number: " + numChild);
        for (int i = 0; i < numChild; i++) {
            View view = rootView.getChildAt(i);
            if (view instanceof ViewGroup) {
                setupAllListeners((ViewGroup) view);
            } else if (view instanceof Button) {
                Button button = (Button) view;
                button.setOnClickListener(this);
            }
            //Log.v(TAG, "View id: " + view.getId());
        }
    }
    //log.v(TAG, "View id: " + view.getId());

    public void displayResult(View view){
        inputText.setText("Result");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonCC:
                inputText.setText("0");
                break;
            default:
                Button button = (Button)v;
                String buttonString = button.getText().toString();
                inputText.setText(buttonString);
                Log.v(TAG, "Log All");
        }
    }
}

